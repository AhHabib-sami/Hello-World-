<?php
echo "<p>Copyright &copy; 2021-" . date("Y") . " Home Finder.com</p>";
